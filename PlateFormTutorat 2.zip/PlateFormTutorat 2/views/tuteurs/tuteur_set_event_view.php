
    <div id="globalContent">
        <div id="wrapper">
            
            <div class="d-flex flex-column" id="content-wrapper">
                <div id="content">
                    <div class="block">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-2">
                                </div>
                                <div class="col-xs-12 col-md-8">
                                    <div class="row">
                                        <div class="card debut">
                                            <div class="card-header py-3">
                                                <p class="text-primary m-0 font-weight-bold">
                                                    Créer
                                                </p>
                                            </div>
                                            <div class="card-body">
                                                <form method="post" action="?controller=evenements&action=set_event" onsubmit="javascript:message();">
                                                    <div class="row">
                                                        <div class="form-group col-xs-12 col-md-6">
                                                            <label for="date">
                                                                <strong>Date</strong><br>
                                                            </label>
                                                            <input class="form-control" type="datetime-local" name="date_creation" required />
                                                        </div>
                                                        <div class="form-group col-xs-12 col-md-6">
                                                            <label for="lieu">
                                                                <strong>Lieu</strong><br> 
                                                            </label>
                                                            <input class="form-control" type="text" placeholder="Lieu" name="lieu" required />
                                                        </div>
                                                        <div class="form-group col-12">
                                                            <label for="tutore">
                                                                <strong>Tutoré</strong><br>
                                                            </label>
                                                            <select class="form-control" name="tutore">
                                                                <option>Franklin Delano</option>
                                                                <option>Delano Roosevelt</option>
                                                                <option>Veirel Delano</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-12">
                                                            <label for="tutore">
                                                                <strong>Durée</strong><br>
                                                            </label>
                                                            <select class="form-control" name="duree">
                                                                <option value="1">1 h</option>
                                                                <option value="2">2 h</option>
                                                                <option value="3">3 h</option>
                                                                <option value="4">4 h</option>
                                                                <option value="5">5 h</option>
                                                                <option value="6">6 h</option>
                                                                <option value="7">7 h</option>

                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group text-center col-12">
                                                        <button class="btn" type="submit">CREER</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
      function  message()
      {
       <?php $_SESSION['alert']= 'l\'évènement a bien été crée. vous le trouverez dans la liste des évènements ' ; ?>
      }
    </script>
    