 <div class="d-flex flex-column" id="content-wrapper">
    <!-- <?php //include('views/alert_view.php'); ?> -->
                <div id="content">
                    <div class="block">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-2">
                                </div>
                                <div class="col-xs-12 col-md-8">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-6 card-container">
                                            <div class="card avenir">
                                                <div class="card-body">
                                                    <h4 class="card-title">Liste</h4>
                                                    
                                                    <a href="?controller=tuteurs&action=waiting_list">
                                                        <button class="btn" type="button">J'ai recu <br/>des demandes</button>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-md-6 card-container">
                                            <div class="card historique">
                                                <div class="card-body">
                                                    <h4 class="card-title">En attente</h4>
                                                    <a href="?controller=evenements&action=display_pasts_events">
                                                        <button class="btn" type="button">Ceux<br/>avec qui je veux travailler</button>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            