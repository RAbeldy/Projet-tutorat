<?php
require_once('models/tuteurs.php');
require_once('models/evenements.php');
require_once('models/users.php');
/* Définition du controller */
class TuteursController
{

    public function interface_tuteur()
    {   
        if( isset($_SESSION['id_statut']))
            require_once('views/tuteurs/interface_tuteur.php');
        else
            require_once('views/login.php');
    }
    public function tuteur_set_event()
    {   if(isset($_SESSION['id_statut']))// on vérifie que seul un utilisateur connecté peut accéder à ces pages
            require_once('views/tuteurs/tuteur_set_event_view.php'); // on charge la vue adéquate
        else
            require_once('views/login.php');
    }

    public function selection_tutores()
    {
        if(isset($_SESSION['id_statut']))// on vérifie que seul un utilisateur connecté peut accéder à ces pages
            require_once('views/tuteurs/interface_selection_tutores_tuteurs.php'); // on charge la vue adéquate
        else
            require_once('views/login.php');
    }

    public function display_all_tutores()
    {
        $tuteurs= new Users();
        if(isset($_SESSION['id_statut']))// on vérifie que seul un utilisateur connecté peut accéder à ces pages
        {
            $donnees= $tuteurs->Get_all_tutores();
            require_once('views/tuteurs/available_tutores_list.php');
        }
        else
            require_once('views/login.php');  
    }
    public function notifications()
    {
        if( isset($_SESSION['id_statut']))
            require_once('views/tuteurs/notifications_tuteurs_view.php');
        else
            require_once('views/login.php');
    }
    public function waiting_list()  // on récuprère la lsite des 
    {
        $tuteurs= new Users();
        if(isset($_SESSION['id_statut']))// on vérifie que seul un utilisateur connecté peut accéder à ces pages
        {   
            $donnees= $tuteurs->Get_waiting_list();
            require_once('views/tuteurs/waiting_tuteurs_list.php');
             
        }
        else
            require_once('views/login.php'); 

    }
    public function link() // action de se lier à un tuteur ou un tutoré
    {
        $tuteurs= new Tuteurs();
        if(isset($_SESSION['id_statut']))// on vérifie que seul un utilisateur connecté peut accéder à ces pages
        {   
             $tuteurs->Link($_POST['id_u']);
            require_once('views/tuteurs/notifications_tuteurs_view.php');
             
        }
        else
            require_once('views/login.php'); 
    }

}
?>