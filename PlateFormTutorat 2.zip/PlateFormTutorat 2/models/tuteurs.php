<?php
require_once('connexion.php');
require('users.php');
require('evenements.php');
class Tuteurs extends users
{
	private $nb_max_mef;
	private $nb_max_perso;
	private $prioritaire;

    public function __construct(){}


    public function getNb_max_mef()
    {
    	return $this->nb_max_mef ;
    }
    public function getNb_max_perso()
    {
    	return $this->nb_max_perso ;
    }
    public function getPrioritaire()
    {
    	return $this->prioritaire ;
    }
    public function setNb_max_mef($nb)
    {
    	 $this->$nb_max_mef= $nb ;
    }
    public function setNb_max_perso($nb)
    {
    	 $this->$nb_max_mef= $nb ;
    }
    public function setPriotaire($statut)
    {
    	 $this->prioritaire = $statut ;
    }

   
    
    public function Modify_info_user() 
    {

    }
    public function Get_info_user()
    {

    }
    public function Link($id_user)
    {
        $db = Db::getInstance();
        $req = $db->prepare(" INSERT INTO matchs (id_tuteurs,id_tutores,date_debut) VALUES (?,?,NOW())");
        $req->execute(array($_SESSION['id_user'],$id_user));
    }


}