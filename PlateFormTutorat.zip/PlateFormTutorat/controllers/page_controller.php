<?php
/* Définition du controller */
class PageController
{

	// page d'authentification
	public function home()  
	{
	   require_once('views/page_pres.php');
	}

}
?>