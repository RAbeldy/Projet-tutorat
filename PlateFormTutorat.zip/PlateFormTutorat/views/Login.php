    <!-- Start: Login screen -->
    <div id="login-one" class="login-one">
        <form class="login-one-form">
            <div class="col">
                <div class="login-one-ico"><i class="fa fa-unlock-alt" id="lockico"></i></div>
                <div class="form-group">
                    <div>
                        <h3 id="heading">Log in:</h3>
                    </div><input class="form-control" type="text" id="input" placeholder="Username"><input class="form-control" type="password" id="input" placeholder="Password"><button class="btn btn-primary" id="button" style="background-color:#007ac9;" type="submit">Log in</button></div>
            </div>
        </form>
    </div>
