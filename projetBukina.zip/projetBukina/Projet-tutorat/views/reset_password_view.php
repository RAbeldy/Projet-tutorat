


<div class="login-dark">
        <form method="post" action="resetPassword.php">
            <h2 class="sr-only">Réinitialiser le mot de passe </h2>
            <div class="illustration">
                <i class="icon ion-person-add"></i>
            </div>
           
          
            <div class="form-group">
                <input class="form-control" type="text" name="reset_email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input class="form-control" type="password" name="password" placeholder="mot de passe" required>
            </div>
            <div class="form-group">
                <input class="form-control" type="password" name="confirm_password" placeholder="confirmer mot de passe" required>
            </div>
            <div class="form-group">
            <button class="btn btn-primary btn-block" id="submit">Réinitialiser</button>
            
            </div>

          </form>
          <div><a href="index.php" class="forgot">Se Connecter</a></div>
     </div>

