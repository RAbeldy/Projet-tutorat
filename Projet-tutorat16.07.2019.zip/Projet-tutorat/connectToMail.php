<?php
	$mailAccount = 'bricenicodem.simeupouomegne@esprit.tn';
	$mail_password ='brlmfkdkrlgzwzhq';
	$mail_host = 'smtp.gmail.com';
	$mail_port = 25;
?>