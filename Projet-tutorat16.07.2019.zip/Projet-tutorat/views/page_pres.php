
    <div class="global_container">
        <header class="block-intro">
            <div class="jumbotron">
                <h1 id="h1bienvenue">BIENVENUE SUR TUTORAT YNCREA</h1>
                <p id="middleJumboParagraph">Lorem Ispum dolor sit amet&nbsp;Lorem Ispum dolor sit amet Lorem Ispum dolor sit amet&nbsp;Lorem Ispum dolor sit amet&nbsp;Lorem Ispum dolor sit amet&nbsp;Lorem Ispum dolor sit amet&nbsp;Lorem Ispum dolor sit amet&nbsp;Lorem Ispum dolor
                    sit amet&nbsp;Lorem Ispum dolor sit amet&nbsp;Lorem Ispum dolor sit amet&nbsp;Lorem Ispum dolor sit amet&nbsp;Lorem Ispum dolor sit amet<br><br></p>
                <p id="callToAction"><a class="btn btn-primary gris" role="button">En savoir plus</a></p>
            </div>
        </header>
        <div class="container">
            <section class="portfolio-block skills">
                <div class="container">
                    <div class="heading">
                        <h2>A PROPOS</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card special-skill-item border-0">
                                <div class="card-header bg-transparent border-0"><img class="cardImage" src="assets/img/1.jpg"></div>
                                <div class="card-body">
                                    <h3 class="card-title">Tutorés</h3>
                                    <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card special-skill-item border-0">
                                <div class="card-header bg-transparent border-0"><img class="cardImage" src="assets/img/2.jpg"></div>
                                <div class="card-body">
                                    <h3 class="card-title">Tuteurs</h3>
                                    <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card special-skill-item border-0">
                                <div class="card-header bg-transparent border-0"><img class="cardImage" src="assets/img/3.jpg"></div>
                                <div class="card-body">
                                    <h3 class="card-title">Superviseurs</h3>
                                    <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card special-skill-item border-0">
                                <div class="card-header bg-transparent border-0"><img class="cardImage" src="assets/img/1.jpg"></div>
                                <div class="card-body">
                                    <h3 class="card-title">Tutorés</h3>
                                    <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card special-skill-item border-0">
                                <div class="card-header bg-transparent border-0"><img class="cardImage" src="assets/img/2.jpg"></div>
                                <div class="card-body">
                                    <h3 class="card-title">Tuteurs</h3>
                                    <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card special-skill-item border-0">
                                <div class="card-header bg-transparent border-0"><img class="cardImage" src="assets/img/3.jpg"></div>
                                <div class="card-body">
                                    <h3 class="card-title">Superviseurs</h3>
                                    <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>