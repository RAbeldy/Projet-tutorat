# Projet-tutorat
Projet de conception d'application web pour le groupe Yncrea


*Utilisation de github dans son local Pour les développeurs*

- Utiliser son invite de commande choisir son repertoire de repo et faire: 
git clone https://github.com/RAbeldy/Projet-tutorat

- Ensuite vérifier que vous avez toutes les branches avec: git branch

- Maintenant que vous avez le projet en local modifier sur vos fichiers en local et chaque midi ou soir faire un: git push sur la branche dev. 

- S'il vous plait ne jamais toucher la branche Master pour le modifier.

- Si vous avez un problème et que vous ne pouvez pas résoudre contacter nous: @junior, @rabeldy, @brice, @steve, @delano, @isaac et @josias
